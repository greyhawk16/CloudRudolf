def lambda_handler(event, context):
    print("server testing. testing is my work!")
